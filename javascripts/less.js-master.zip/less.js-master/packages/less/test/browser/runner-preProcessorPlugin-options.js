var less = {logLevel: 4,
    errorReporting: 'console',
    plugins: [preProcessorPlugin]};
