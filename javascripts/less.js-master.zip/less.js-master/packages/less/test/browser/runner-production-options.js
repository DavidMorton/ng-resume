var less = {logLevel: 1,
    errorReporting: 'console'};
less.env = 'production';
